===============================================
Power YMF 2.0.1 RELEASE NOTES
===============================================

This file contains important supplementary and
late-breaking information that may not appear
in the main product documentation. We recommend
that you read this file in its entirety.

Note: the package contains the common documentation
for Full and Lite versions.



CONTENTS
===============================================
-- INSTALLATION NOTES (READ BEFORE CONTINUING)
-- REMOVING PRODUCT
-- OTHER RELEASE NOTES INCLUDED WITH THIS PRODUCT
-- PRODUCT ON THE WEB



INSTALLATION NOTES
===============================================
The following items describe known issues,
behavior, and functionality that can affect
installation of this product.


Minimum system requirements
-----------------------------------------------
* Yamaha 7x4 chip-based soundcard;
* Intel Pentium 166 processor or higher;
* OS: Microsoft Windows 95/98/Me/2000/XP;
* Memory: 32 MB;
* 4 MB hard disk space;


If you've installed product before
-----------------------------------------------
You can install to the same machine (though to
a different location) as another version of the
product. If you want to install to the same
directory as an existing version, uninstall the
existing version first. In either case, you
should back up your own XG bank files (if present)
and any other important data, including
existing bank files that you intend to use with
this version. You should also restore the original
bank mode before installation.


Starting the installation program
-----------------------------------------------
Run "PYMF.EXE" for begin install.


Installation directory
-----------------------------------------------
By default, Power YMF installs
into the directory:

  \Program Files\TranceIn\Power YMF\<version>



REMOVING PRODUCT
===============================================
To uninstall Power YMF from
your computer, restore the original wavetable bank
bode, open the Control Panel folder
and double-click the Add/Remove Programs icon.
Select "Power YMF" from the
list, then click the Add/Remove button. Follow
the instructions that appear on the screen.



OTHER RELEASE NOTES
INCLUDED WITH THIS PRODUCT
===============================================

FILE_ID.DIZ contains general information about
the product.

LICENSE.TXT contains information on
licensing allowances and limitations for this
product.

Other information present in online help system.



PRODUCT ON THE WEB
===============================================

Company home page:
  http://www.yohng.com/powerymf/

Product home page:
  http://www.yohng.com/powerymf/

OSS/3D home page:
  http://www.oss3d.com/

Support via E-mail:
  trancein@trancein.com

===============================================
Copyright (C) 2002 by George Yohng
Copyright (C) 2001-2002, TranceIn
Copyright (C) 2001-2002, Atrise Software Co.
All rights reserved
